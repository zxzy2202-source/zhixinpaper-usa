import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { ensureBlogPostSchema } from "@/lib/db/ensureBlogPostSchema";
import { blogPosts } from "@/lib/db/schema";
import { and, eq } from "drizzle-orm";
import { BLOG_POSTS, BLOG_CATEGORY_IMAGES } from "@/lib/data";
import BlogPostClient from "./BlogPostClient";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { buildMetadata, canonicalUrl } from "@/lib/seo";

const STATIC_POST_SEO: Record<string, { title: string; keywords: string[] }> = {
  "thermal-paper-roll-sizes-guide": {
    title: "Thermal Paper Roll Sizes Guide",
    keywords: [
      "thermal paper roll size guide",
      "thermal paper roll dimensions",
      "thermal paper roll size chart",
      "how to measure thermal paper roll",
      "3 1/8 thermal paper",
      "2 1/4 thermal paper rolls",
    ],
  },
  "thermal-paper-printer-compatibility-guide": {
    title: "Thermal Paper Printer Compatibility Guide",
    keywords: [
      "thermal printer paper",
      "thermal paper printer compatibility",
      "receipt printer paper rolls",
      "paper for thermal printer",
      "payment terminal paper compatibility",
      "POS printer paper size",
    ],
  },
};

// ISR：文章页静态化，后台保存时 revalidatePath(`/blog/${slug}`) 即时刷新
export const revalidate = 300;

export async function generateStaticParams() {
  return BLOG_POSTS.map((post) => ({ slug: post.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;

  let dbPost = null;
  try {
    await ensureBlogPostSchema();
    dbPost = await db
      .select()
      .from(blogPosts)
      .where(and(eq(blogPosts.slug, slug), eq(blogPosts.status, "published")))
      .then((rows) => rows[0]);
  } catch {}

  if (dbPost) {
    const title = dbPost.seoTitle || dbPost.title;
    const description = dbPost.seoDescription || dbPost.excerpt || "";
    const metadata = buildMetadata({
      title,
      description,
      path: `/blog/${slug}`,
      image: dbPost.coverImage || undefined,
    });
    return {
      ...metadata,
      openGraph: {
        ...metadata.openGraph,
        title: dbPost.title,
        description: dbPost.excerpt || description,
        type: "article",
        publishedTime: dbPost.publishedAt || dbPost.createdAt,
        modifiedTime: dbPost.updatedAt,
        authors: ["Zhixin Paper"],
      },
    };
  }

  const post = BLOG_POSTS.find((p) => p.slug === slug);
  if (!post) return { title: "Article Not Found" };
  const staticSeo = STATIC_POST_SEO[slug];
  const metadata = buildMetadata({
    title: staticSeo?.title || post.title,
    description: post.excerpt,
    path: `/blog/${slug}`,
  });
  return {
    ...metadata,
    openGraph: {
      ...metadata.openGraph,
      title: post.title,
      description: post.excerpt,
      type: "article",
      publishedTime: post.date,
      modifiedTime: post.date,
      authors: ["Zhixin Paper"],
    },
  };
}

export default async function BlogPostPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  let dbPost = null;
  let publishedDbPosts: {
    slug: string;
    title: string;
    category: string;
    readTime: string;
    date: string;
  }[] = [];
  try {
    await ensureBlogPostSchema();
    dbPost = await db
      .select()
      .from(blogPosts)
      .where(and(eq(blogPosts.slug, slug), eq(blogPosts.status, "published")))
      .then((rows) => rows[0]);
    const publishedRows = await db
      .select({
        slug: blogPosts.slug,
        title: blogPosts.title,
        category: blogPosts.category,
        readTime: blogPosts.readTime,
        publishedAt: blogPosts.publishedAt,
        createdAt: blogPosts.createdAt,
      })
      .from(blogPosts)
      .where(eq(blogPosts.status, "published"));
    publishedDbPosts = publishedRows.map((post) => ({
      slug: post.slug,
      title: post.title,
      category: post.category || "General",
      readTime: post.readTime || "5 min",
      date: post.publishedAt || post.createdAt,
    }));
  } catch {}

  if (dbPost) {
    const articleSchema = {
      "@context": "https://schema.org",
      "@type": "Article",
      headline: dbPost.title,
      description: dbPost.excerpt || "",
      datePublished: dbPost.publishedAt || dbPost.createdAt,
      dateModified: dbPost.updatedAt,
      author: { "@type": "Organization", name: "Zhixin Paper", url: "https://www.zhixinpaper.com" },
      publisher: {
        "@type": "Organization",
        name: "Zhixin Paper",
        url: "https://www.zhixinpaper.com",
        logo: { "@type": "ImageObject", url: "https://www.zhixinpaper.com/images/logo.png" },
      },
      mainEntityOfPage: { "@type": "WebPage", "@id": `https://www.zhixinpaper.com/blog/${slug}` },
      image: dbPost.coverImage || canonicalUrl(BLOG_CATEGORY_IMAGES[dbPost.category || ""] ?? BLOG_CATEGORY_IMAGES.default),
    };

    return (
      <>
        <Header />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
        <BlogPostClient
          slug={slug}
          dbPost={{
            id: dbPost.id,
            slug: dbPost.slug,
            title: dbPost.title,
            excerpt: dbPost.excerpt || "",
            content: dbPost.content,
            category: dbPost.category || "General",
            tags: dbPost.tags || "",
            readTime: dbPost.readTime || "5 min read",
            coverImage: dbPost.coverImage || null,
            publishedAt: dbPost.publishedAt,
            createdAt: dbPost.createdAt,
             status: dbPost.status,
           }}
           publishedDbPosts={publishedDbPosts}
         />
        <Footer />
      </>
    );
  }

  const post = BLOG_POSTS.find((p) => p.slug === slug);
  if (!post) notFound();

  const postImage = canonicalUrl(BLOG_CATEGORY_IMAGES[post.category] ?? BLOG_CATEGORY_IMAGES.default);

  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: post.title,
    description: post.excerpt,
    image: postImage,
    datePublished: post.date,
    dateModified: post.date,
    author: { "@type": "Organization", name: "Zhixin Paper", url: "https://www.zhixinpaper.com" },
    publisher: {
      "@type": "Organization",
      name: "Zhixin Paper",
      url: "https://www.zhixinpaper.com",
      logo: { "@type": "ImageObject", url: "https://www.zhixinpaper.com/images/logo.png" },
    },
    mainEntityOfPage: { "@type": "WebPage", "@id": `https://www.zhixinpaper.com/blog/${slug}` },
  };

  return (
    <>
      <Header />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      <BlogPostClient slug={slug} dbPost={null} publishedDbPosts={publishedDbPosts} />
      <Footer />
    </>
  );
}
